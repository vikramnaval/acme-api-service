const express = require('express');
const router = express.Router();

router.get('/products', (req, res) => {
  res.json([{ id: 1, name: 'Anvil' }, { id: 2, name: 'Rocket Skates' }]);
});

module.exports = router;
