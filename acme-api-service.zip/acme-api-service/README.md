# Acme API Service

This is a fictional REST API for managing Acme Corp products.

## Setup

```bash
npm install
npm start
```

## Endpoints

- `GET /api/products` - List all products
